package kyrxstudios.moonmoney;

/**
 * Created by lyric on 12/4/2017.
 */

public class RewardedVideoAdListener {
}
